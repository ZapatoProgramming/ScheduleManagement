import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


public class MM extends JFrame  {

    private JButton button1;
    private JButton habitaciónesLibresButton;
    private JButton registerRoomButton;
    private JButton roomCheckButton;
    private JPanel INICIAL;
    private JButton registerSeasonButton;
    private JButton roomReservationButton;
    private JButton scheduleButton;
    private JButton applyOperationsButton;
    private JButton exitButton;
    public int activo = 0;
    public MM() {

        setContentPane(INICIAL);
        setTitle("Unified Course Registration Interface");
        setSize(590, 590);

        setVisible(true);

        button1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e){
            try {

                ResultSet rs = TransactionMySQL.stmt.executeQuery("SELECT * FROM ROOM");

                DefaultTableModel model = new DefaultTableModel();
                JTable table = new JTable(model);

                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();

                // Add columns to the table model
                for (int i = 1; i <= columnCount; i++) {
                    model.addColumn(metaData.getColumnLabel(i));
                }

                // Add rows to the table model
                while (rs.next()) {
                    Object[] row = new Object[columnCount];
                    for (int i = 1; i <= columnCount; i++) {
                        row[i - 1] = rs.getObject(i);
                    }
                    model.addRow(row);
                }

                // Display the JTable in a JFrame
                JFrame frame = new JFrame();
                frame.add(new JScrollPane(table));
                frame.pack();
                frame.setVisible(true);

                // Close the database connection
                rs.close();
                TransactionMySQL.stmt.close();
                TransactionMySQL.conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }



        }




        });
        button1.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent u) {
                activo = +1;
                if (activo == 1)

                {
                    //Se llama el constructor

                    setVisible(false);
                }

            }
        });
        habitaciónesLibresButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent h) {


            }
        });


        roomCheckButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {


            }
        });
        registerSeasonButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    RegisterS registerS = new RegisterS();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                setVisible(false);

            }
        });
        habitaciónesLibresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    RegisterC registerc = new RegisterC();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                setVisible(false);
            }
        });
        applyOperationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    TransactionMySQL.conn.commit();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        registerRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    RegisterR registerR = new RegisterR();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                setVisible(false);
            }


        });

        scheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    Schedule schedule = new Schedule();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                setVisible(false);

            }
        });

    }

}

